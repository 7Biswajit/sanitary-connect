import "./App.css";

function About() {
  return (
    <div className="About">
      <h2>WE ARE THE LARGEST DISTRIBUTER IN THE WORLD</h2>
      <div className="para">
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut mollitia
          id, quae delectus consequatur repudiandae iure fuga temporibus
          deleniti quos earum dignissimos minima impedit dolorem sapiente sunt.
          Eos animi ducimus et distinctio adipisci fuga ea quas reprehenderit
          vero cumque natus vitae cum eius provident in quaerat magnam laborum,
          eligendi eveniet? Consequuntur, officia. In quasi fuga minus a eaque
          optio tempore commodi ut suscipit quod ab sunt reprehenderit maiores
          aliquam similique, nihil dicta culpa pariatur repellat quaerat
          blanditiis quisquam vel possimus. Aspernatur repellat odio maiores
          architecto eum, laborum assumenda sapiente! Minima suscipit dolorum
          modi debitis doloremque molestias delectus voluptates cumque magni. In
          sit magni tenetur. Nobis minus voluptatibus, earum eos quos
          repellendus perspiciatis odit harum recusandae ipsum sunt maiores
          explicabo aperiam? Sequi ipsa magni vero officiis nulla ex voluptatum?
          A sapiente iure similique earum, soluta iste accusamus nisi, nihil
          animi mollitia nulla maiores aliquam quia dolor quos, inventore
          suscipit voluptate harum. Natus, fugiat fuga dolorum autem sint,
          dolores deleniti id consectetur voluptas, ab ex. Laborum quas sapiente
          itaque voluptatum mollitia praesentium vitae ratione neque dolorum? Ab
          quasi, esse nam numquam voluptatibus unde perspiciatis illum,
          praesentium iste a hic sint necessitatibus sequi aut id, temporibus
          nobis delectus error iusto! Quam, nam nobis?
        </p>
      </div>
      <hr />
      <div className="boxes">
        <div className="box-1">
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Obcaecati
            tenetur optio, voluptates esse rerum magnam expedita? Asperiores est
            laudantium maxime, ad deleniti, vel dignissimos dolores praesentium
        
          </p>
        </div>
        <div className="box-1">
          <p>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sequi
            molestiae sint, facere quam aliquam fuga autem quibusdam dolorem
     
          </p>
        </div>

        <div className="box-1">
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus
            ea earum in modi molestias neque veritatis vero corporis
           
          </p>
        </div>
        <div className="box-1">
          <p>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sit, hic
            vero eligendi delectus quo beatae mollitia labore nam aliquam in non
   
          </p>
        </div>
      </div>
    </div>
  );
}

export default About;
