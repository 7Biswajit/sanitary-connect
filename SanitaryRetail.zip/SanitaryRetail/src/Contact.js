
import "./App.css";
function Contact() {
  return (
   <div className="forms">
       <input type="text" placeholder="ENTER YOUR NAME" />
       <input type="text" placeholder="ENTER YOUR AGE" />
       <input type="email" placeholder="MORE YOUR EMAIL" />
       <input type="text" placeholder="MORE ABOUT YOU" />
       <button>submit
       </button>
   </div>
  );
}

export default Contact;
