
import "./App.css";
function Footer() {
  return (
    <div className="footer">
        copyright &copy; -ALL RIGHT RESERVED
    </div>
  );
}

export default Footer;
