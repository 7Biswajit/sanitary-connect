import "./App.css";

function Home() {
  return (
    <section className="firstsection">
      <div className="box">
        <p className="small">
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure,
          aspernatur.
        </p>
        <p className="big">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores,
          inventore ex ipsum accusantium quaerat iure obcaecati reiciendis
          impedit voluptates. Consequuntur sint nesciunt aut corrupti quibusdam
          architecto maiores sunt, praesentium facere neque illo repellat
          explicabo perferendis dolor non, numquam officia? Dolore cupiditate,
          optio repellendus quod eum veritatis pariatur, ut reprehenderit
          quaerat accusamus, esse harum commodi sit cumque! Explicabo minus
          tempore voluptates esse quis. Ipsum sed dolorum similique excepturi
          nesciunt doloribus dolorem harum, quisquam suscipit possimus
          perspiciatis, obcaecati sint nisi deleniti tenetur a natus nemo
          reiciendis provident deserunt quos! Nam possimus nisi facilis dicta
          tenetur sit, consequuntur cum, illo magnam quas quae.
        </p>
      </div>

      <div className="img">
        <img src="logo512.png" alt="img" />
      </div>
    </section>
  );
}

export default Home;
