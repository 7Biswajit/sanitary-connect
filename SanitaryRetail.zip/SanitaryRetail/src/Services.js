import "./App.css";
function Services() {
  return (
    <div className="services">
      <div className="container-1">
        <h3>OUR PASSION IS YOUR SUCCESS</h3>
        <div>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos veniam
          cum atque a vel numquam voluptates, beatae, error, sapiente veritatis
          nihil tempore. Hic alias quisquam rerum earum aspernatur eaque
          laudantium eligendi quasi? Accusamus, aspernatur eius autem sapiente
          ipsum beatae tempora hic quaerat magni? Perspiciatis voluptatum qui
          dicta quidem in id!
        </div>
      </div>
    </div>
  );
}

export default Services;
